### Script to analize simulated data
setwd("~/Desktop/evol_slim")
library("spgs", lib.loc="/Library/Frameworks/R.framework/Versions/3.5/Resources/library")
library(magrittr)
library(dplyr)
library(stringr)
library("RGenetics", lib.loc="/Library/Frameworks/R.framework/Versions/3.5/Resources/library")
library(MASS)
library(AER)
library(pscl)
library(MuMIn)
library(entropy)

# read the file with all possible pairs of codon-aa
possible.pairs <- read.delim("input/slim_possible_pairs_events.txt", stringsAsFactors = FALSE)
# frequencies of codons
codons.freqs <- read.delim("input/slim_codon_frequencies.txt")
# mutation rates of individual substitution types
mutRates.substitutions <- read.delim("input/slim_mut_spectrum.txt")
# numbers of mutational paths of given type
pathsAC <- read.delim("input/A-C.txt")
pathsAG <- read.delim("input/A-G.txt")
pathsAT <- read.delim("input/A-T.txt")
pathsCA <- read.delim("input/C-A.txt")
pathsCG <- read.delim("input/C-G.txt")
pathsCT <- read.delim("input/C-T.txt")
pathsGA <- read.delim("input/G-A.txt")
pathsGC <- read.delim("input/G-C.txt")
pathsGT <- read.delim("input/G-T.txt")
pathsTA <- read.delim("input/T-A.txt")
pathsTC <- read.delim("input/T-C.txt")
pathsTG <- read.delim("input/T-G.txt")


PopSize <- c("PopSize=1e3","PopSize=1e4","PopSize=1e5","PopSize=1e6","PopSize=1e7")
Porcentage <- c(1,5,10,50,100)
DFE <- 1:38
combined <- expand.grid(DFE,PopSize,Porcentage,stringsAsFactors = T)
output <- data.frame(Betas = 1:(length(PopSize)*length(Porcentage)*length(DFE)),stringsAsFactors = FALSE);

for (file in 1:(length(PopSize)*length(Porcentage)*length(DFE))) {
  
  # remove the yeast events
  possible.pairs$events <- 0
  
  events <- read.delim(paste0("./final_output/events_DFEn",combined[[1]][file],"_",combined[[2]][file],"_DFEp",combined[[3]][file],".dat",collapse = " "),header = F,stringsAsFactors = F)[[1]]
  
  data <- data.frame(Chromosome = rep("chr1",each=1,length.out=length(events)),stringsAsFactors = FALSE);
  
  for (i in 1:length(events)) {
    temp <- events[i]
    if (nchar(temp)>6) next
    data$Mutation[i] <- sub(":.*","",temp);
    data$Position[i] <- as.numeric(sub(".*:","",temp))+1;
    if(data$Position[i]%%3==0){
      temp.bed <- data.frame(Chromosome = data$Chromosome[i], start = data$Position[i] - 3, end = data$Position[i])
      write.table(temp.bed, "temp.bed", sep="\t",quote=FALSE, row.names = FALSE, col.names = FALSE)
      data$Codon[i] <- system("bedtools getfasta -fi genome.fasta -bed temp.bed",intern = TRUE)[2]
      temp.AA <- strsplit(data$Codon[i],"")[[1]]
      temp.AA[3] <- data$Mutation[i]
      data$new.AA[i] <- codonToAAone(paste(temp.AA,collapse = ""))
      if(data$new.AA[i]=="Stop"){
        data$new.AA[i] <- "STOP"
      }
    }else if(data$Position[i]%%3==2){
      temp.bed <- data.frame(Chromosome = data$Chromosome[i], start = data$Position[i] - 2, end = data$Position[i] + 1)
      write.table(temp.bed, "temp.bed", sep="\t",quote=FALSE, row.names = FALSE, col.names = FALSE)
      data$Codon[i] <- system("bedtools getfasta -fi genome.fasta -bed temp.bed",intern = TRUE)[2]
      temp.AA <- strsplit(data$Codon[i],"")[[1]]
      temp.AA[2] <- data$Mutation[i]
      data$new.AA[i] <- codonToAAone(paste(temp.AA,collapse = ""))
      if(data$new.AA[i]=="Stop"){
        data$new.AA[i] <- "STOP"
      }
    }else{
      temp.bed <- data.frame(Chromosome = data$Chromosome[i], start = data$Position[i] - 1, end = data$Position[i] + 2)
      write.table(temp.bed, "temp.bed", sep="\t",quote=FALSE, row.names = FALSE, col.names = FALSE)
      data$Codon[i] <- system("bedtools getfasta -fi genome.fasta -bed temp.bed",intern = TRUE)[2]
      temp.AA <- strsplit(data$Codon[i],"")[[1]]
      temp.AA[1] <- data$Mutation[i]
      data$new.AA[i] <- codonToAAone(paste(temp.AA,collapse = ""))
      if(data$new.AA[i]=="Stop"){
        data$new.AA[i] <- "STOP"
      }
    }
  } 
  
  #remove NAs
  data<-na.omit(data)
  
  # count the events
  synon <- c()
  j <- 0
  for (k in 1:nrow(data)) {
    if (data$new.AA[k]=="STOP") next
    index <- possible.pairs$codon==data$Codon[k] & possible.pairs$alt_aa==data$new.AA[k]
    possible.pairs$events[index] <- possible.pairs$events[index] + 1
    if(sum(index)<1){
      j <- j + 1
      synon[j]<-k
    }
  }
  
  if(length(synon)>0)
    data <- data[-synon,]
  
  output$Events[file]<-nrow(data)
  
  # prepare data frame to store the data
  data.reg <- data.frame(codon = possible.pairs$codon,
                         to_aa = possible.pairs$alt_aa,
                         events = possible.pairs$events,
                         frequency = NA,
                         AC = NA, AG = NA, AT = NA,
                         CA = NA, CG = NA, CT = NA,
                         GA = NA, GC = NA, GT = NA,
                         TA = NA, TC = NA, TG = NA
  )
  
  output$Paths[file]<-sum(data.reg$events>0)/391
  
  for(k in 1:nrow(data.reg)) {
    data.reg$frequency[k] <- codons.freqs$frequency[codons.freqs$codon==data.reg$codon[k]]
    data.reg$AC[k] <- pathsAC[,colnames(pathsAC)==data.reg$to_aa[k]][pathsAC$codon==data.reg$codon[k]]
    data.reg$AG[k] <- pathsAG[,colnames(pathsAG)==data.reg$to_aa[k]][pathsAG$codon==data.reg$codon[k]]
    data.reg$AT[k] <- pathsAT[,colnames(pathsAT)==data.reg$to_aa[k]][pathsAT$codon==data.reg$codon[k]]
    data.reg$CA[k] <- pathsCA[,colnames(pathsCA)==data.reg$to_aa[k]][pathsCA$codon==data.reg$codon[k]]
    data.reg$CG[k] <- pathsCG[,colnames(pathsCG)==data.reg$to_aa[k]][pathsCG$codon==data.reg$codon[k]]
    data.reg$CT[k] <- pathsCT[,colnames(pathsCT)==data.reg$to_aa[k]][pathsCT$codon==data.reg$codon[k]]
    data.reg$GA[k] <- pathsGA[,colnames(pathsGA)==data.reg$to_aa[k]][pathsGA$codon==data.reg$codon[k]]
    data.reg$GC[k] <- pathsGC[,colnames(pathsGC)==data.reg$to_aa[k]][pathsGC$codon==data.reg$codon[k]]
    data.reg$GT[k] <- pathsGT[,colnames(pathsGT)==data.reg$to_aa[k]][pathsGT$codon==data.reg$codon[k]]
    data.reg$TA[k] <- pathsTA[,colnames(pathsTA)==data.reg$to_aa[k]][pathsTA$codon==data.reg$codon[k]]
    data.reg$TC[k] <- pathsTC[,colnames(pathsTC)==data.reg$to_aa[k]][pathsTC$codon==data.reg$codon[k]]
    data.reg$TG[k] <- pathsTG[,colnames(pathsTG)==data.reg$to_aa[k]][pathsTG$codon==data.reg$codon[k]]
  }
  
  data.reg$log_frequency <- log(data.reg$frequency)
  data.reg$pathsCount <- data.reg$AC + data.reg$AG + data.reg$AT +
    data.reg$CA + data.reg$CG + data.reg$CT +
    data.reg$GA + data.reg$GC + data.reg$GT +
    data.reg$TA + data.reg$TC + data.reg$TG
  data.reg$log_pathsCount <- log(data.reg$pathsCount)
  data.reg$log_avgMutRate <- log((mutRates.substitutions["A","C"]*data.reg$AC +
                                    mutRates.substitutions["A","G"]*data.reg$AG +
                                    mutRates.substitutions["A","T"]*data.reg$AT +
                                    mutRates.substitutions["C","A"]*data.reg$CA +
                                    mutRates.substitutions["C","G"]*data.reg$CG +
                                    mutRates.substitutions["C","T"]*data.reg$CT +
                                    mutRates.substitutions["G","A"]*data.reg$GA + 
                                    mutRates.substitutions["G","C"]*data.reg$GC +
                                    mutRates.substitutions["G","T"]*data.reg$GT +
                                    mutRates.substitutions["T","A"]*data.reg$TA +
                                    mutRates.substitutions["T","C"]*data.reg$TC +
                                    mutRates.substitutions["T","G"]*data.reg$TG)/data.reg$pathsCount)
  
  data.reg$log_mutAll <- data.reg$log_avgMutRate+data.reg$log_pathsCount
  
  skip_to_next <- FALSE
  tryCatch(mod.nb <- glm.nb(events ~ offset(log_frequency) + log_mutAll, data = data.reg,control = glm.control(maxit = 500)), error = function(e) { skip_to_next <<- TRUE})
  
  if(skip_to_next) { 
    output$Betas[file] <- NA
    output$stderr[file] <- NA
    output$pval[file] <- NA
    output$R2[file]<-NA
    output$eventscorr[file]<- NA
    output$eventscorrpval[file]<- NA
  }
  else{
    resumen <- summary(mod.nb)
    output$Betas[file] <- resumen[11]$coefficients[2]
    output$stderr[file] <- resumen[11]$coefficients[4]
    output$pval[file] <- resumen[11]$coefficients[8]
    output$R2[file]<-1-(mod.nb$deviance/mod.nb$null.deviance)
    newdat <- data.frame(log_frequency=data.reg$log_frequency,log_mutAll=data.reg$log_mutAll)
    fit <- predict.glm(mod.nb,newdata=newdat,type = "response")
    output$eventscorr[file]<- cor(as.matrix(cbind(fit,data.reg$events),type = "pearson"))[2]
    output$eventscorrpval[file]<- as.numeric(cor.test(fit,data.reg$events,type = "pearson")[3])
  }
  
  output$DFE[file]<-as.character(combined[[1]][file])
  output$PopSize[file]<-as.character(combined[[2]][file])
  output$Percentage[file]<-combined[[3]][file]
  data.reg$log_events<-data.reg$events
  data.reg$log_events[data.reg$log_events==0]<- 0.5
  data.reg$log_y<-data.reg$log_events/data.reg$log_frequency
  
  output$Spearman[file]<-cor(as.matrix(data.reg[,c(21,23)],type = "spearman"))[2]
  
  output$entropy[file]<-entropy(data.reg$events)/entropy(rep(1/length(data.reg$events),length(data.reg$events)))
  
  rm(data,data.reg)
}
output   
write.table(output, "outputfinal40paths.txt", sep="\t", quote=FALSE, row.names = FALSE)

MyGray <- rgb(t(col2rgb("black")), alpha=50, maxColorValue=255)
plot(data.reg$log_mutAll,log(data.reg$events),xlab = "Mut_prob",ylab = "Number of events",col=MyGray,pch=20)


