for sizes in $(cat sizes.txt); do
		for (( i = 0; i < 2; i++ )); do
			File='File="./DFE_88.txt"'
			slim -l 0 -d ${sizes} -d "${File}" evol.slim
		done
done
