for sizes in $(cat sizes.txt); do
	for perc in $(cat porcentages.txt); do
		for files in $(ls record_output/out_*_$sizes_$perc.txt); do
			tail -1 $files >> ./record_output/events_$sizes_$perc.dat
			echo "" >> ./record_output/events_$sizes_$perc.dat 
			#rm $files
		done
	done
done

