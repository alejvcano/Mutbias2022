%Input file
outputfinal.Supply=outputfinal.PopSize*0.0000001;

%Fig2
symbols=['wo';'w^';'wd';'ws';'wv';'wp'];
t = linspace(0.01, 1, 50);  %arbitrary bounds and number of points
subplot(2,3,1);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
for j=1:length(symbols)
scatter(sasvsempYeast.empirical(j),sasvsempYeast.sas(j),100,symbols(j,:),'filled','MarkerEdgeColor','k','LineWidth',1.5);
end
hold off
box on
ylabel({'Frequency among';'adaptive substitutions'});
set(gca,'FontSize',14);
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
xlabel('')
ylim([0.01 1])
xlim([0.01 1])
subplot(2,3,2);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
for j=1:length(symbols)
scatter(sasvsempEcoli.empirical(j),sasvsempEcoli.sas(j),100,symbols(j,:),'filled','MarkerEdgeColor','k','LineWidth',1.5);
end
hold off
box on
xlabel('Empirical mutation rate');
set(gca,'FontSize',14);
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
set(gca,'YTickLabel',[]);
ylabel('')
ylim([0.01 1])
xlim([0.01 1])
subplot(2,3,3);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
for j=1:length(symbols)
scatter(sasvsempMTB.empirical(j),sasvsempMTB.sas(j),100,symbols(j,:),'filled','MarkerEdgeColor','k','LineWidth',1.5);
end
hold off
box on
set(gca,'FontSize',14);
ylim([0.01 1])
xlim([0.01 1])
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
xlabel('')
set(gca,'YTickLabel',[]);
ylabel('')
t = linspace(0.01, 1000, 50);  %arbitrary bounds and number of points
subplot(2,3,4);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
scatter(dataYeast.predevents+1+(rand(1,length(dataYeast.predevents))*0.3)',dataYeast.events+1+(rand(1,length(dataYeast.events))*0.3)','k','filled','MarkerFaceAlpha',.25);
box on
ylim([0.85 25])
ylabel({'Observed';'adaptive events'});
xlabel('Predicted mutational events');
set(gca,'FontSize',14);
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
xlim([0.85 25])
xlabel('')
subplot(2,3,5);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
scatter(dataEcoli.predevents+1+(rand(1,length(dataEcoli.predevents))*0.3)',dataEcoli.events+1+(rand(1,length(dataEcoli.events))*0.3)','k','filled','MarkerFaceAlpha',.25);
box on
ylabel({'Observed';'adaptive events'});
xlabel('Predicted adaptive events');
set(gca,'FontSize',14);
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
ylim([0.9 100])
xlim([0.9 100])
ylabel('')
subplot(2,3,6);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
scatter(dataMTB.predevents+1+(rand(1,length(dataMTB.predevents))*0.3)',dataMTB.events+1+(rand(1,length(dataMTB.events))*0.3)','k','filled','MarkerFaceAlpha',.25);
box on
ylabel('Observed mutational events');
xlabel('Predicted mutational events');
set(gca,'FontSize',14);
set(gca, 'YScale', 'log')
set(gca, 'XScale', 'log')
ylim([0.9 1000])
xlim([0.9 1000])
xlabel('')
ylabel('')

%Fig3
subplot(2,3,1)
histogram(Yeastspecgen,20,'Normalization','probability','FaceColor','w','EdgeColor','k')
ylim([0 0.5]);
set(gca,'FontSize',14);
ylabel('Frequency');
%xlim([-150 50]);
subplot(2,3,2)
histogram(Ecolispecgen,20,'Normalization','probability','FaceColor','w','EdgeColor','k')
set(gca,'Yticklabel',[]) 
ylim([0 0.5]);
%xlim([-150 50]);
set(gca,'FontSize',14);
xlabel('Difference in log-likelihood');
subplot(2,3,3)
histogram(MTBspecgen,20,'Normalization','probability','FaceColor','w','EdgeColor','k')
set(gca,'Yticklabel',[]) 
ylim([0 0.5]);
set(gca,'FontSize',14);
symbols=['wo';'w^';'wd';'ws';'wv';'wp'];
t = linspace(0.01, 1, 50);  %arbitrary bounds and number of points
subplot(2,3,4);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
for j=1:length(symbols)
scatter(idealvsempYeast.ideal(j),idealvsempYeast.empirical(j),100,symbols(j,:),'filled','MarkerEdgeColor','k','LineWidth',1.5);
end
hold off
box on
ylabel('Empirical mutation rate');
set(gca,'FontSize',14);
xlim([0.01 1])
ylim([0.01 1])
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
xlabel('')
subplot(2,3,5);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
for j=1:length(symbols)
scatter(idealvsempEcoli.ideal(j),idealvsempEcoli.empirical(j),100,symbols(j,:),'filled','MarkerEdgeColor','k','LineWidth',1.5);
end
hold off
box on
xlabel('Inferred mutation rate');
set(gca,'FontSize',14);
xlim([0.01 1])
ylim([0.01 1])
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
set(gca,'YTickLabel',[]);
ylabel('')
subplot(2,3,6);
plot(t, t,'k','LineWidth',1.5,'LineStyle','--');
hold on
for j=1:length(symbols)
scatter(idealvsempMTB.ideal(j),idealvsempMTB.empirical(j),100,symbols(j,:),'filled','MarkerEdgeColor','k','LineWidth',1.5);
end
hold off
box on
set(gca,'FontSize',14);
xlim([0.01 1])
ylim([0.01 1])
xlabel('')
set(gca,'YTickLabel',[]);
ylabel('')
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')

%Fig4
uniquesupply=unique(outputfinal.Supply);
subplot(2,3,5)
hold on
shadedErrorBar(unique(outputfinal.Supply),grpstats(outputfinal.entropy,outputfinal.Supply),grpstats(outputfinal.entropy,outputfinal.Supply,'std'),'lineProps',{'-k','LineWidth',1,'markerfacecolor','k'});
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(1)),outputfinal.entropy(outputfinal.Supply==uniquesupply(1)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(1))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.000025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(2)),outputfinal.entropy(outputfinal.Supply==uniquesupply(2)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(2))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.00025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(3)),outputfinal.entropy(outputfinal.Supply==uniquesupply(3)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(3))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.0025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(4)),outputfinal.entropy(outputfinal.Supply==uniquesupply(4)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(4))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(5)),outputfinal.entropy(outputfinal.Supply==uniquesupply(5)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(5))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.25);
set(gca, 'XScale', 'log')
xlabel('Mutation supply (N\mu)');
xlim([0.00007 1.4])
box on
colormap(gray(5));
set(gca,'ColorScale','log');
set(gca,'FontSize',14);
ylabel({'Entropy of the observed spectrum';'of adaptive substitutions'});
hold off
subplot(2,3,[1,4])
t = linspace(0.000001, 1000, 50);  %arbitrary bounds and number of points
plot(t, zeros(length(t)),'k','LineWidth',1.0,'LineStyle','--');
hold on
plot(t, zeros(length(t))+1,'k','LineWidth',1.0,'LineStyle','--');
shadedErrorBar(unique(outputfinal.Supply),grpstats(outputfinal.Betas,outputfinal.Supply),grpstats(outputfinal.Betas,outputfinal.Supply,'std'),'lineProps',{'-k','LineWidth',1,'markerfacecolor','k'});
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(2)),outputfinal.Betas(outputfinal.Supply==uniquesupply(2)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(2))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.00025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(1)),outputfinal.Betas(outputfinal.Supply==uniquesupply(1)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(1))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.000025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(3)),outputfinal.Betas(outputfinal.Supply==uniquesupply(3)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(3))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.0025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(4)),outputfinal.Betas(outputfinal.Supply==uniquesupply(4)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(4))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(5)),outputfinal.Betas(outputfinal.Supply==uniquesupply(5)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(5))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.25);
hold off
set(gca, 'XScale', 'log')
xlabel('Mutation supply (N\mu)');
ylabel('Mutation coefficient \beta');
xlim([0.00007 1.4])
ylim([-8 6])
yticks([-8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6]);
box on
colormap(gray(5));
set(gca,'ColorScale','log');
set(gca,'FontSize',14);
subplot(2,3,2)
hold on
shadedErrorBar(unique(outputfinal.Supply),grpstats(outputfinal.eventscorr,outputfinal.Supply),grpstats(outputfinal.eventscorr,outputfinal.Supply,'std'),'lineProps',{'-k','LineWidth',1,'markerfacecolor','k'});
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(1)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(1)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(1))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.000025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(2)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(2)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(2))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.00025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(3)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(3)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(3))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.0025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(4)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(4)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(4))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.025);
scatter(outputfinal.Supply(outputfinal.Supply==uniquesupply(5)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(5)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(5))./100,'filled','MarkerEdgeColor','k', 'jitter','on', 'jitterAmount',0.25);
set(gca, 'XScale', 'log')
ylabel({'Correlation between predicted and';'observed spectra of adaptive subtitutions'});
xlim([0.00007 1.4])
box on
colormap(gray(5));
set(gca,'ColorScale','log');
set(gca,'FontSize',14);
xlabel('');
set(gca,'XTickLabel',[]);
subplot(2,3,[3,6])
xline(0.90,'LineWidth',1,'LineStyle','--');
hold on
xline(0.79,'LineWidth',1,'LineStyle','--');
xline(0.54,'LineWidth',1,'LineStyle','--');
scatter(outputfinal.entropy(outputfinal.Supply==uniquesupply(1)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(1)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(1))./100,'filled','o','MarkerEdgeColor','k');
scatter(outputfinal.entropy(outputfinal.Supply==uniquesupply(2)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(2)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(2))./100,'filled','d','MarkerEdgeColor','k');
scatter(outputfinal.entropy(outputfinal.Supply==uniquesupply(3)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(3)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(3))./100,'filled','s','MarkerEdgeColor','k');
scatter(outputfinal.entropy(outputfinal.Supply==uniquesupply(4)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(4)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(4))./100,'filled','v','MarkerEdgeColor','k');
scatter(outputfinal.entropy(outputfinal.Supply==uniquesupply(5)),outputfinal.eventscorr(outputfinal.Supply==uniquesupply(5)),[],outputfinal.Percentage(outputfinal.Supply==uniquesupply(5))./100,'filled','^','MarkerEdgeColor','k');
box on
xlim([0 1]);
colormap(gray(5));
ylabel({'Correlation between predicted and';'observed spectra of adaptive subtitutions'});
xlabel({'Entropy of the observed spectrum';'of adaptive substitutions'});
set(gca,'FontSize',14);

%FigS1
dataYeast.frequency=dataYeast.frequency/1000;
color_yeast=[0 0 0];
color_ecoli=[0.65 0.65 0.65];
color_mtb=[1 1 1];
yeast_spec=[14.4 35.0 6.3 11.0 18.2 15.1];
ecoli_spec=[21.4 34.7 7.42 16.59 12.69 7.19];
mtb_spec=[24.51 37.24 2.54 11.53 10.99 13.19];
figure
subplot(5,4,[1,2,5,6]);
mutation_spectra = [14.4 21.4 24.51; 35.0 34.7 37.24; 6.3 7.42 2.54; 11.0 16.59 11.53; 18.2 12.69 10.99; 15.2 7.19 13.19];
bar(mutation_spectra)
ylabel('Relative mutation rates');
set(gca,'XTickLabel',{'A>G,T>C';'G>A,C>T';'A>T,T>A';'A>C,T>G';'G>T,C>A';'G>C,C>G'});
legend('{\it S. cerevisiae}','{\it E. coli}','{\it M. tuberculosis}');
subplot(5,4,3);
yeast_ecoli_diff=yeast_spec./ecoli_spec;
b=bar(yeast_ecoli_diff);
b.FaceColor = 'flat';
b.CData((yeast_ecoli_diff<1),:) = repmat(color_ecoli,sum((yeast_ecoli_diff<1)),1);
b.CData((yeast_ecoli_diff>1),:) = repmat(color_yeast,sum((yeast_ecoli_diff>1)),1);
set(gca,'XTickLabel',{'A>G';'G>A';'A>T';'A>C';'G>T';'G>C'});
yticks([1/3 1/2 2/3 1 3/2 2 3]);
yticklabels({'1/3','1/2','2/3','1','3/2','2','3'});
xtickangle(45);
b(1).BaseValue = 1;
set(gca, 'YScale', 'log')
ylabel('Relat diff({\itS. cerev},{\it E. coli})')
ylim([0.3 3]);
subplot(5,4,4);
yeast_mtb_diff=yeast_spec./mtb_spec;
b=bar(yeast_mtb_diff);
b.FaceColor = 'flat';
b.CData((yeast_mtb_diff<1),:) = repmat(color_mtb,sum((yeast_mtb_diff<1)),1);
b.CData((yeast_mtb_diff>1),:) = repmat(color_yeast,sum((yeast_mtb_diff>1)),1);
set(gca,'XTickLabel',{'A>G';'G>A';'A>T';'A>C';'G>T';'G>C'});
yticks([1/3 1/2 2/3 1 3/2 2 3]);
yticklabels({'1/3','1/2','2/3','1','3/2','2','3'});
xtickangle(45);
set(gca, 'YScale', 'log')
b(1).BaseValue = 1;
ylabel('Relat diff({\itS. cerev},{\it M. tuber})')
ylim([0.3 3]);
subplot(5,4,8);
mtb_ecoli_diff=mtb_spec./ecoli_spec;
b=bar(mtb_ecoli_diff);
b.FaceColor = 'flat';
b.CData((mtb_ecoli_diff<1),:) = repmat(color_ecoli,sum((mtb_ecoli_diff<1)),1);
b.CData((mtb_ecoli_diff>1),:) = repmat(color_mtb,sum((mtb_ecoli_diff>1)),1);
set(gca,'XTickLabel',{'A>G';'G>A';'A>T';'A>C';'G>T';'G>C'});
yticks([1/3 1/2 2/3 1 3/2 2 3]);
yticklabels({'1/3','1/2','2/3','1','3/2','2','3'});
xtickangle(45);
set(gca, 'YScale', 'log')
b(1).BaseValue = 1;
ylim([0.3 3]);
ylabel('Relat diff({\itM. tuber},{\it E. coli})')
subplot(5,4,[9:12]);
bar(unique(dataYeast.codon,"stable"),unique(dataYeast.frequency,"stable"))
ylim([0 0.063])
set(gca,'XTickLabel',[]);
subplot(5,4,[13:16]);
bar(unique(dataEcoli.codon,"stable"),unique(dataEcoli.frequency,"stable"))
ylim([0 0.063]);
set(gca,'XTickLabel',[]);
ylabel('Codon frequencies');
subplot(5,4,[17:20]);
bar(unique(dataMTB.codon,"stable"),unique(dataMTB.frequency,"stable"))
ylim([0 0.063]);

%FigS2
boxplot([outputmstudyyeastzeros.corr outputmstudyecolizeros.corr outputmstudymtbzeros.corr],'Symbol','k.','Colors','k','labels',{'S. cerevisiae','E. coli','M. tuberculosis'});
ylim([0 1]);
set(gca,'FontSize',14);
ylabel('Correlation between simulated and predicted events')
hold on
scatter(0.7,0.68,80,'w>','filled','MarkerEdgeColor','k','LineWidth',1);
scatter(1.7,0.4,80,'w>','filled','MarkerEdgeColor','k','LineWidth',1);
scatter(2.7,0.16,80,'w>','filled','MarkerEdgeColor','k','LineWidth',1);
hold off

%FigS3
subplot(3,1,1)
plot(unique(outputfinal.Supply),grpstats(outputfinal.pval,outputfinal.Supply),'-ok','MarkerFaceColor','w','LineWidth',1);
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log') 
set(gca,'FontSize',14);
xlim([0.00007 1.4])
ylim([0.001 0.5])
xlabel('Mutation supply (N\mu)');
ylabel('{\it p} mut coeff \beta');
set(gca,'XTickLabel',[]);
xlabel('')
box on
subplot(3,1,2)
plot(unique(outputfinal.Supply),grpstats(outputfinal.stderr,outputfinal.Supply),20,'-ok','MarkerFaceColor','w','LineWidth',1);
ylabel('Std. error mut coeff \beta');
set(gca, 'XScale', 'log')
set(gca,'FontSize',14);
box on
xlim([0.00007 1.4])
set(gca,'XTickLabel',[]);
xlabel('')
subplot(3,1,3)
plot(unique(outputfinal.Supply),grpstats(outputfinal.eventscorrpval,outputfinal.Supply),'-ok','MarkerFaceColor','w','LineWidth',1);
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
set(gca,'FontSize',14);
xlim([0.00007 1.4])
xlabel('Mutation supply (N\mu)');
ylabel('{\it p} correlation');

%FigS4
subplot(4,2,1)
boxplot([contaminationecoli.GenBeta5 contaminationecoli.GenBeta10 contaminationecoli.GenBeta15 contaminationecoli.GenBeta20 contaminationecoli.GenBeta25],'Symbol','k.','Colors','k','labels',{'10%','20%','30%','40%','50%'});
set(gca,'FontSize',14);
ylabel('Mutation coefficient \beta');
ylim([0 1])
subplot(4,2,2)
boxplot([contaminationyeast.GenBeta5 contaminationyeast.GenBeta10 contaminationyeast.GenBeta15 contaminationyeast.GenBeta20 contaminationyeast.GenBeta25],'Symbol','k.','Colors','k','labels',{'10%','20%','30%','40%','50%'});
set(gca,'FontSize',14);
ylabel('')  
xlabel('')
ylim([0 1.1])
subplot(4,2,3)
boxplot([contaminationecoli.pval5 contaminationecoli.pval10 contaminationecoli.pval15 contaminationecoli.pval20 contaminationecoli.pval25],'Symbol','k.','Colors','k','labels',{'10%','20%','30%','40%','50%'});
set(gca,'FontSize',14);
ylabel('{\it p} mut coeff \beta');
subplot(4,2,4)
boxplot([contaminationyeast.pval5 contaminationyeast.pval10 contaminationyeast.pval15 contaminationyeast.pval20 contaminationyeast.pval25],'Symbol','k.','Colors','k','labels',{'10%','20%','30%','40%','50%'});
set(gca,'FontSize',14);
ylabel('')
xlabel('')
subplot(4,2,5)
boxplot([contaminationecoli.eventscorr5 contaminationecoli.eventscorr10 contaminationecoli.eventscorr15 contaminationecoli.eventscorr20 contaminationecoli.eventscorr25],'Symbol','k.','Colors','k','labels',{'10%','20%','30%','40%','50%'});
set(gca,'FontSize',14);
ylabel({'Correlation between observed';'and predicted events'});
ylim([0 0.45])
subplot(4,2,6)
boxplot([contaminationyeast.eventscorr5 contaminationyeast.eventscorr10 contaminationyeast.eventscorr15 contaminationyeast.eventscorr20 contaminationyeast.eventscorr25],'Symbol','k.','Colors','k','labels',{'10%','20%','30%','40%','50%'});
set(gca,'FontSize',14);
ylabel('')
xlabel('')
ylim([0 0.7])
subplot(4,2,7)
boxplot([contaminationecoli.pcorr5 contaminationecoli.pcorr10 contaminationecoli.pcorr15 contaminationecoli.pcorr20 contaminationecoli.pcorr25],'Symbol','k.','Colors','k','labels',{'10%','20%','30%','40%','50%'});
set(gca,'FontSize',14);
ylabel('{\it p} correlation');
%ylim([5*10^(-16) [30*10^(-16)]])
subplot(4,2,8)
boxplot([contaminationyeast.pcorr5 contaminationyeast.pcorr10 contaminationyeast.pcorr15 contaminationyeast.pcorr20 contaminationyeast.pcorr25],'Symbol','k.','Colors','k','labels',{'10%','20%','30%','40%','50%'});
set(gca,'FontSize',14);
ylabel('')
xlabel('')
fractionecoli5=sum((contaminationecoli.GenBeta5+contaminationecoli.ci5>1)&(contaminationecoli.GenBeta5-contaminationecoli.ci5<1))/1000;
fractionecoli10=sum((contaminationecoli.GenBeta10+contaminationecoli.ci10>1)&(contaminationecoli.GenBeta10-contaminationecoli.ci10<1))/1000;
fractionecoli15=sum((contaminationecoli.GenBeta15+contaminationecoli.ci15>1)&(contaminationecoli.GenBeta15-contaminationecoli.ci15<1))/1000;
fractionecoli20=sum((contaminationecoli.GenBeta20+contaminationecoli.ci20>1)&(contaminationecoli.GenBeta20-contaminationecoli.ci20<1))/1000;
fractionecoli25=sum((contaminationecoli.GenBeta25+contaminationecoli.ci25>1)&(contaminationecoli.GenBeta25-contaminationecoli.ci25<1))/1000;
fractionyeast5=sum((contaminationyeast.GenBeta5+contaminationyeast.ci5>1)&(contaminationyeast.GenBeta5-contaminationyeast.ci5<1))/1000;
fractionyeast10=sum((contaminationyeast.GenBeta10+contaminationyeast.ci10>1)&(contaminationyeast.GenBeta10-contaminationyeast.ci10<1))/1000;
fractionyeast15=sum((contaminationyeast.GenBeta15+contaminationyeast.ci15>1)&(contaminationyeast.GenBeta15-contaminationyeast.ci15<1))/1000;
fractionyeast20=sum((contaminationyeast.GenBeta20+contaminationyeast.ci20>1)&(contaminationyeast.GenBeta20-contaminationyeast.ci20<1))/1000;
fractionyeast25=sum((contaminationyeast.GenBeta25+contaminationyeast.ci25>1)&(contaminationyeast.GenBeta25-contaminationyeast.ci25<1))/1000;
subplot(1,2,1)
plot([fractionecoli5 fractionecoli10 fractionecoli15 fractionecoli20 fractionecoli25],'-ok','MarkerFaceColor','w','LineWidth',1);
set(gca,'FontSize',14);
ylim([-0.1 1.1])
xlabel('Contamination percentage');
ylabel('fraction of simulated cases in which the CI for beta includes 1');
xlabel('')
box on
subplot(1,2,2)
plot([fractionyeast5 fractionyeast10 fractionyeast15 fractionyeast20 fractionyeast25],'-ok','MarkerFaceColor','w','LineWidth',1);
set(gca,'FontSize',14);
ylim([-0.1 1.1])
xlabel('Contamination percentage');
ylabel('fraction of simulated cases in which the CI for beta includes 1');
xlabel('')
box on

%FigS5
subplot(5,1,5);
histogram(DFE1,'Normalization','probability','FaceColor','w','BinWidth',0.015,'BinMethod','sturges');
set(gca,'FontSize',14);
xlim([-0.8 0.25])
xlabel('Selection coefficient');
subplot(5,1,4);
histogram(DFE5,'Normalization','probability','FaceColor','w','BinWidth',0.015,'BinMethod','sturges');
set(gca,'FontSize',14);
xlim([-0.8 0.25])
subplot(5,1,3);
histogram(DFE10,'Normalization','probability','FaceColor','w','BinWidth',0.015,'BinMethod','sturges');
set(gca,'FontSize',14);
xlim([-0.8 0.25])
subplot(5,1,2);
histogram(DFE50,'Normalization','probability','FaceColor','w','BinWidth',0.015,'BinMethod','sturges');
set(gca,'FontSize',14);
xlim([-0.8 0.25])
ylim([0 0.7])
subplot(5,1,1);
histogram(DFE100,'Normalization','probability','FaceColor','w','BinWidth',0.015,'BinMethod','sturges');
set(gca,'FontSize',14);
xlim([-0.8 0.25])